DEMO
2. Create virtual environment that you will use for the project and activate it (python3.8+ required):
   1. **python3 -m venv my_venv/**
   2. **source my_venv/bin/activate**
2. Install the package 
   1. **pip3 install stock_summary_tool**
3. Go to https://rapidapi.com and log in.
4. Go to https://rapidapi.com/sparior/api/yahoo-finance15/ and obtain your API key.
5. Save your key for the project:
   1. **stock_summary_tool save-token <YOUR_TOKEN>**


